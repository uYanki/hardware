#ifndef __LED_H
#define __LED_H


void Led_Init(void);
void Led_Display(u16 Dual,u16 Seg);
void Led_Display_All(void);


#endif