#ifndef __DELAY_H

#define __DELAY_H

void Delayus(void);

void Delayms(unsigned int time);

void Delayus_Trig(void); 

#endif


